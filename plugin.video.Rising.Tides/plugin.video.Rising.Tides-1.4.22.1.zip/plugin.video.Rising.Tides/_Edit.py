import xbmcaddon

MainBase = 'http://bit.ly/MICASA_1'
addon = xbmcaddon.Addon('plugin.video.Rising.Tides')