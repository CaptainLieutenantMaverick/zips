# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)


import os           
import xbmc         
import xbmcaddon    
import xbmcplugin   

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File



debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PLZc2vaaVVzP5bh2J2OclmStVyHhSkEMam"
YOUTUBE_CHANNEL_ID_2 = "PLZc2vaaVVzP7IxlX-KN4jTuhvbL_0aJw_"
YOUTUBE_CHANNEL_ID_3 = "PLZc2vaaVVzP6YFVmqgQ-zWB0eLx1vlGOy"
YOUTUBE_CHANNEL_ID_4 = "PLZc2vaaVVzP5R-94nYSs5hQBY3f_8HaEL"
YOUTUBE_CHANNEL_ID_5 = "PLZc2vaaVVzP6bC23p0YX4SeAlwX_6sFBE"
YOUTUBE_CHANNEL_ID_6 = "PLZc2vaaVVzP47IcH7GKi0du8juUxpqzYn"
YOUTUBE_CHANNEL_ID_7 = "PLZc2vaaVVzP4fr80bvNvbPB1kcMHZ-mLc"
YOUTUBE_CHANNEL_ID_8 = "PLZc2vaaVVzP4Nw6I-_rmm_cUpK0zC3rXI"
YOUTUBE_CHANNEL_ID_9 = "PLZc2vaaVVzP5hlz25VI8eNcikgDfX3ZUj"
YOUTUBE_CHANNEL_ID_10 = "PLZc2vaaVVzP4NDQ6EjssdLoSRwHiCGcbd"
YOUTUBE_CHANNEL_ID_11 = "PLZc2vaaVVzP6obgZoqAGGh31go4WO0sxO"
YOUTUBE_CHANNEL_ID_12 = "PLZc2vaaVVzP7k3FQijAgD_WXmNoYwa5cQ"
YOUTUBE_CHANNEL_ID_13 = "PLZc2vaaVVzP77co4ZGUfkULuF7sLmwjTw"
YOUTUBE_CHANNEL_ID_14 = "PLZc2vaaVVzP7xyn0gwPE3ywWSNnygs3BD"
YOUTUBE_CHANNEL_ID_15 = "PLZc2vaaVVzP5eYIpdaZb8YdWQmgw60U6M"
YOUTUBE_CHANNEL_ID_16 = "PLZc2vaaVVzP64uLSeS7ihhS5WWoFTxfUg"
YOUTUBE_CHANNEL_ID_17 = "PLZc2vaaVVzP77asA7Qo11oOZvBQDj-Zhn"
YOUTUBE_CHANNEL_ID_18 = "PLZc2vaaVVzP7QRSmqJ9SekZinlVKfe_Oh"
YOUTUBE_CHANNEL_ID_19 = "PLZc2vaaVVzP6D8fTwEPy2Zj7Lssa-lpRZ"


@route(mode='main_menu')
def Main_Menu():


        

	Add_Dir( 
		name="Primer reviews", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Primerreviews.png")
	Add_Dir(
		name="DIY waxing", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/DIYwaxing.png")
	Add_Dir(
		name="80's Hair & makeup", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/80sHair.png")
	Add_Dir(
		name="Lip plumping", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Lipplumping.png")
	Add_Dir(
		name="60's Hair & makeup", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/60sHair.png")
	Add_Dir(
		name="40's Hair & makeup", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/40sHair.png")
	Add_Dir(
		name="Contour & highlight", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Contour.png")
	Add_Dir(
		name="Lipsticks & gloss", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Lipsticks.png")
	Add_Dir(
		name="Eyebrow's & eyeliner etc", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Eyebrows.png")
	Add_Dir(
		name="Everyday makeup looks", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Everydaymakeup.png")
	Add_Dir(
		name="Glam & night time makeup", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Glam.png")
	Add_Dir(
		name="Foundation & concealer", url=BASE+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Foundation.png")
	Add_Dir(
		name="Beauty hacks", url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Beautyhacks.png")
	Add_Dir(
		name="Hair tutorials", url=BASE+YOUTUBE_CHANNEL_ID_14+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Hairtutorials.png")
	Add_Dir(
		name="Celeb hair & makeup looks", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Celebhair.png")
	Add_Dir(
		name="Fake tanning", url=BASE+YOUTUBE_CHANNEL_ID_16+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Faketanning.png")
	Add_Dir(
		name="Man section", url=BASE+YOUTUBE_CHANNEL_ID_17+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Mansection.png")
	Add_Dir(
		name="Fancy dress/Halloween etc", url=BASE+YOUTUBE_CHANNEL_ID_18+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Fancydress.png")
	Add_Dir(
		name="Beauty sleep", url=BASE+YOUTUBE_CHANNEL_ID_19+"/", folder=True,
		icon="http://grindhousekodi.tk/grindhouse/images/beauty/Beautysleep.png")




#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

	
if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))